package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.domain.Book;

@RestController
public class eBookConsumerController {
	
	@Autowired
	@Qualifier("restTemplate")
	private RestTemplate restTemplate;
	
	@GetMapping("/books/{id}")
	public Book getbookbyid(@PathVariable("id")Integer id) {
		
		Book books =restTemplate.getForObject("http://product-service/books/" +id, Book.class);
		return books;
	}
}
