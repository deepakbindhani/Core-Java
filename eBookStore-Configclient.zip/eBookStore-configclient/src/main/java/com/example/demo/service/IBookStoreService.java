package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.domain.Book;

public interface IBookStoreService {
	
	Book save(Book book);
	Book update(Book book);
	void delete(int id);
	List<Book> getAllBooks();
	
	Book getBookById(int id);
	List<Book> getAllBookByName(String name);
	List<Book> getAllBookByPrice(int price);
	void patchBook(Map<String, Object> updates,int id);
}
